import tensorflow as tf
tf.compat.v1.disable_eager_execution()
from tensorflow import keras
import datetime
import time
from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, Activation, Dropout
import numpy as np

from art.attacks.evasion import DeepFool
from art.estimators.classification import KerasClassifier
from art.utils import load_cifar10

start = time.time()
# 데이터 셋 로드
(x_train, y_train), (x_test, y_test), min_pixel_value, max_pixel_value = load_cifar10()

# 모델 생성
model = Sequential()
model.add(Conv2D(32, (3, 3), padding="same", input_shape=x_train.shape[1:]))
model.add(Activation("relu"))
model.add(Conv2D(32, (3, 3)))
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(64, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(Conv2D(64, (3, 3)))
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(512))
model.add(Activation("relu"))
model.add(Dropout(0.5))
model.add(Dense(10))
model.add(Activation("softmax"))

model.compile(loss="categorical_crossentropy", optimizer="adam", metrics=["accuracy"])

# ART 분류기 생성
classifier = KerasClassifier(model=model, clip_values=(min_pixel_value, max_pixel_value), use_logits=False)

# ART 분류기 훈련
classifier.fit(x_train, y_train, batch_size=64, nb_epochs=20)

# 정상적으로 학습시킨 모델에 대한 정확도 평가
preds = classifier.predict(x_test)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("정상적으로 학습시킨 모델의 정확도: {}%".format(acc * 100))

# DeepFool 공격
attack = DeepFool(classifier=classifier, max_iter=5, epsilon=0.2)
x_test_adv = attack.generate(x=x_test)

# DeepFool 공격 이후 모델에 대한 정확도 평가
preds = classifier.predict(x_test_adv)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("DeepFool 공격 이후 정확도: {}%".format(acc * 100))

sec = time.time() - start
times = str(datetime.timedelta(seconds=sec)).split(".")
times = times[0]
print(times)
