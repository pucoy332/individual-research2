import tensorflow as tf
tf.compat.v1.disable_eager_execution()
from tensorflow import keras
import time
import datetime
from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D
import numpy as np

from art.attacks.evasion import FastGradientMethod
from art.estimators.classification import KerasClassifier
from art.utils import load_mnist

start = time.time()

# 데이터 셋 로드
(x_train, y_train), (x_test, y_test), min_pixel_value, max_pixel_value = load_mnist()

# 모델 생성
model = Sequential()
model.add(Conv2D(filters=4, kernel_size=(5, 5), strides=1, activation="relu", input_shape=(28, 28, 1)))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(filters=10, kernel_size=(5, 5), strides=1, activation="relu", input_shape=(23, 23, 4)))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Flatten())
model.add(Dense(100, activation="relu"))
model.add(Dense(10, activation="softmax"))

model.compile(
    loss=keras.losses.categorical_crossentropy, optimizer=keras.optimizers.Adam(lr=0.01), metrics=["accuracy"]
)

# ART 분류기 생성
classifier = KerasClassifier(model=model, clip_values=(min_pixel_value, max_pixel_value), use_logits=False)

# ART 분류기 훈련
classifier.fit(x_train, y_train, batch_size=64, nb_epochs=20)

# 정상적으로 학습시킨 모델에 대한 정확도 평가
preds = classifier.predict(x_test)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("정상적으로 학습시킨 모델의 정확도: {}%".format(acc * 100))

# FGSM 공격
attack = FastGradientMethod(estimator=classifier, eps=0.2)
x_test_adv = attack.generate(x=x_test)

# FGSM 공격 이후 모델에 대한 정확도 평가
preds = classifier.predict(x_test_adv)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("FGSM 공격 이후 정확도: {}%".format(acc * 100))

sec = time.time() - start
times = str(datetime.timedelta(seconds=sec)).split(".")
times = times[0]
print(times)
