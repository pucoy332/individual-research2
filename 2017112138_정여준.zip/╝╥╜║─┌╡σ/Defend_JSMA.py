import tensorflow as tf
tf.compat.v1.disable_eager_execution()
from tensorflow import keras
import datetime
import time
from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D
import numpy as np

from art.attacks.evasion import SaliencyMapMethod
from art.estimators.classification import KerasClassifier
from art.utils import load_iris
from art.defences.trainer import AdversarialTrainer


start = time.time()
# 데이터 셋 로드
(x_train, y_train), (x_test, y_test), min_pixel_value, max_pixel_value = load_iris()

# 모델 생성
model = Sequential()
model.add(Dense(10,input_dim=4, activation='relu',kernel_initializer='he_normal'))
model.add(keras.layers.BatchNormalization())
model.add(keras.layers.Dropout(0.3))
model.add(Dense(7, activation='relu', kernel_initializer='he_normal',kernel_regularizer=keras.regularizers.l1_l2(l1=0.001, l2=0.001)))
model.add(keras.layers.BatchNormalization())
model.add(keras.layers.Dropout(0.3))
model.add(Dense(5, activation='relu', kernel_initializer='he_normal',kernel_regularizer=keras.regularizers.l1_l2(l1=0.001,l2=0.001)))
model.add(Dense(3,activation='softmax'))

model.compile(
    loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy']
)
# ART 분류기 생성
classifier = KerasClassifier(model=model, clip_values=(min_pixel_value, max_pixel_value), use_logits=False)

# ART 분류기 훈련
classifier.fit(x_train, y_train, batch_size=7, nb_epochs=700)

# 정상적으로 학습시킨 모델에 대한 정확도 평가
preds = classifier.predict(x_test)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("정상적으로 학습시킨 모델의 정확도: {}%".format(acc * 100))

# JSMA 공격
attack = SaliencyMapMethod(classifier=classifier)
x_test_adv = attack.generate(x=x_test)

# JSMA 공격 이후 모델에 대한 정확도 평가
preds = classifier.predict(x_test_adv)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("JSMA 공격 이후 정확도: {}%".format(acc * 100))

# 정확도 비교를 위한 AdversarialTrainer 훈련
AdversarialTrainer(classifier=classifier, attacks=attack, ratio=0.5).fit(x=x_train, y=y_train, batch_size=7, nb_epochs=700)

# 공격을 방어한 이후 모델의 정확도
preds = AdversarialTrainer(classifier=classifier, attacks=attack, ratio=0.5).predict(x=x_test_adv)
acc = np.sum(np.argmax(preds, axis=1) == np.argmax(y_test, axis=1)) / len(y_test)
print("공격을 방어한 이후 모델 정확도: {}%".format(acc * 100))

sec = time.time() - start
times = str(datetime.timedelta(seconds=sec)).split(".")
times = times[0]
print(times)